#include "Manager.h"
/* MAIN DO MANAGER by call RUN()*/
int main(void)
{
	Manager manager;
	manager.run("command.txt");
	return 0;
}
	
