#include "AlphabetNode.h"



AlphabetNode::AlphabetNode()
{
	alphabet = '\0';
	this->bst = new WordBST;
	pLeft = '\0';
	pRight = '\0';
	pNext = '\0';
}


AlphabetNode::~AlphabetNode()
{
	delete bst;
}

char AlphabetNode::GetAlphabet(){ return alphabet; } //return private value
AlphabetNode* AlphabetNode::GetLeft(){ return pLeft; }
AlphabetNode* AlphabetNode::GetRight(){ return pRight; }
AlphabetNode* AlphabetNode::GetNext(){ return pNext; }
void AlphabetNode::SetAlphabet(char alphabet){ this->alphabet = alphabet; } //Set private value
void AlphabetNode::SetLeft(AlphabetNode* node){ this->pLeft = node; }
void AlphabetNode::SetRight(AlphabetNode* node){ this->pRight = node;}
void AlphabetNode::SetNext(AlphabetNode* node){ this->pNext = node;}
