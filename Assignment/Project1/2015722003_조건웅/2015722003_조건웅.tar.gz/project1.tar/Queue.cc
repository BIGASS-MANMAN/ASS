#include "Queue.h"
#include <string>
#include <fstream>
Queue::Queue()
{
	pHead = '\0';
}
Queue::~Queue() //distructor
{
	WordNode *pNew = new WordNode(); //delete node head to tail
	while(pHead!='\0')
	{
		pNew = pHead; 
		pHead = pHead->GetNext();
		delete pNew; 
	}
}

void Queue::Push(WordNode * node)
{
	WordNode *pPre = '\0'; 	//Push function. 
	if(pHead == '\0') //if empty
	{
		pHead = node; 
	}
	else //add to tail
	{
		pPre = pHead;
		while(pPre->GetNext()!= '\0')
			pPre = pPre->GetNext();
		pPre->SetNext(node);	
		node->SetNext('\0');
	}
}				
WordNode * Queue::Pop() //Pop function
{
	WordNode *pPop = pHead; 

	if(pHead == '\0')
	{
		return '\0';
	}
	pHead = pPop->GetNext(); //return root and change root to next
	pPop->SetNext('\0');
	return pPop; 
}					
WordNode *	Queue::Search(char * word) //Search function
{
	WordNode *p = pHead;
	if(pHead=='\0')
		return '\0'; 
	while(p->GetNext()!='\0')
	{
		if(!strncmp(word,p->GetWord(),strlen(word))){ //compare first to end
			return p;
		}
		p = p->GetNext();
	}
	return '\0'; 
}	

bool Queue::Print()  //Print function
{
	WordNode *p = pHead;
	std::ofstream log;
	if(pHead=='\0')
	{
		return false; 
	}
	else 
	{
		log.open("log.txt",std::ios::app); //to Log file
		log << "======== PRINT ========" << std::endl;
		while(p!='\0')
		{
			log << p->GetWord() << " " << p->GetMean() << std::endl;
			p = p->GetNext();
		}
		log << "=======================" << std::endl;
		log.close();
		return true;
		
	}
	
}							
bool Queue::Save()
{
	WordNode *p = pHead; //Save to to_memorize_word.txt
	if(pHead=='\0')
	{
		return false; 
	}
	else 
	{
		std::ofstream fout;
		fout.open("to_memorize_word.txt",std::ios::out);
		if(fout=='\0')
			return false;
		while(p!='\0')
		{
			fout << p->GetWord() << "\t" << p->GetMean() << std::endl;
			p = p->GetNext();
		}
		fout.close();
		return true;
	}
}								
