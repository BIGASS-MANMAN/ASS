#include "CircularLinkedList.h"
#include <cstring>


CircularLinkedList::CircularLinkedList()
{
	pHead = '\0';
}

CircularLinkedList::~CircularLinkedList()
{
	WordNode *pTemp = pHead;
	while(pTemp != pHead)
	{ 
		pHead = pTemp->GetNext();
		delete pTemp;
		pTemp = pHead;
	}
	delete pHead;
}

void CircularLinkedList::Insert(WordNode * node)// LOAD, TEST
{
	WordNode *pPre = '\0';
	if(pHead == '\0')
	{
		this->pHead = node;
		node->SetNext(pHead);
	}
	else
	{
		pPre = pHead; 
		while(pPre->GetNext()!=pHead)
			pPre = pPre->GetNext();
		pPre->SetNext(node);
		node->SetNext(pHead);
	} 
}

WordNode *	CircularLinkedList::Search(char * word)// SEARCH, UPDATE
{
	WordNode *p = pHead; //Ž����� 
	if(pHead=='\0')
		return '\0'; 
	while(p->GetNext()!=pHead)
	{
		if(strncmp(word,p->GetWord(),strlen(word))==0) //Compare Word
			return p;
		p = p->GetNext();
	}
	return '\0'; //����Ʈ�� ��ġ�ϴ� �ܾ ���� ��
}		

bool CircularLinkedList::Print()// PRINT
{
	WordNode *p = pHead;
	if(pHead=='\0')
	{
		return false; 
	}
	else 
	{
		std::ofstream log;
		log.open("log.txt",std::ios::app);
		log << "======== PRINT ========" << std::endl;
		if(p!='\0')
			log << p->GetWord() << " " << p->GetMean() << std::endl;
		p = p->GetNext();
		while(p->GetNext()!=pHead)
		{
			log << p->GetWord() << " " << p->GetMean() << std::endl;
			p = p->GetNext();
		}
		log << "=====================" << std::endl << std::endl;
		log.close();
		return true;
	}
}							
bool CircularLinkedList::Save()// SAVE
{
	WordNode *p = pHead;
	if(pHead=='\0')
	{
		return false; 
	}
	else 
	{
		std::fstream fout;
		fout.open("memorized_word.txt",std::ios_base::out);
		if(p!='\0')
			fout << p->GetWord() << "\t" << p->GetMean() << std::endl;
		p = p->GetNext();
		while(p!=pHead)
		{
			fout << p->GetWord() << "\t" << p->GetMean() << std::endl;
			p = p->GetNext();
		}
		fout.close();
		return true;
	}
}
