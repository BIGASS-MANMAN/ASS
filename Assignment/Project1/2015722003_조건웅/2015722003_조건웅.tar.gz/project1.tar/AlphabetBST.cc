#include "AlphabetBST.h"
#include <iostream>
AlphabetBST::AlphabetBST()
{
	root = '\0';
	WordCnt = 0;
	char A[26] = {'P', 'H', 'X', 'D', 'L', 'T', 'Z', 'B', 'F', 'J', 'N', 'R', 'V', 'Y', 'A', 'C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W'}; //Make BST
	for(int i=0;i<26;i++){
		AlphabetNode * temp = new AlphabetNode;
		temp->SetAlphabet(A[i]); //make new AlphabetNode
		Insert(temp); //Insert tob bst
	}
}


AlphabetBST::~AlphabetBST()
{
	AlphabetNode* temp;
	temp = root;
	while(temp == '\0'){
	}
}

void AlphabetBST::Insert(AlphabetNode* node){ //Inser function
	if(root == '\0'){
		root = node;
		return;
	}
	AlphabetNode *pPrev = root, *pPrev_Prev = '\0';
	while(pPrev){
		pPrev_Prev = pPrev;
		if(pPrev->GetAlphabet() < node->GetAlphabet()) //if larger value 
			pPrev = pPrev->GetRight(); //go right
		else				//if smaller value
			pPrev = pPrev->GetLeft(); //go left
	}
	if(pPrev_Prev->GetAlphabet() < node->GetAlphabet()) //go to parent node
		pPrev_Prev->SetRight(node);
	else
		pPrev_Prev->SetLeft(node);
	return;
}
bool AlphabetBST::Print(char *order){ //Print function
	char * List[10] ={"R_PRE", "R_IN", "R_POST", "I_LEVEL", "I_PRE","I_IN", "I_POST" }; //Order List
	int flag;
	for(flag = 0;strncmp(List[flag],order,strlen(List[flag]));flag++); //Compare to Order
	switch(flag){ //Call function
	case 0: 	R_PRE(root, order);	break;
	case 1:		R_IN(root, order);	break;
	case 2:		R_POST(root, order);	break;
	case 3:		I_LEVEL(order);		break;
	case 4:		R_PRE(root,order);		break;
	case 5:		R_IN(root,order);		break;
	case 6:		R_POST(root,order);		break;
	default:	break;
	}
	return true;
}
AlphabetNode* AlphabetBST::Search(char alphabet){ //Search function
	AlphabetNode *pSe = root, *pp = '\0';
	while(pSe){
		char _alphabet = pSe->GetAlphabet();
		if(_alphabet < 97) //Change big to small
			_alphabet += 32;
		pp = pSe;
		if(_alphabet == alphabet)
			return pSe;
		if(_alphabet  < alphabet) //Search alphabet
			pSe = pSe->GetRight();
		else if(_alphabet > alphabet)
			pSe = pSe->GetLeft();
	}
	return '\0';
}
bool AlphabetBST::Save(){ //Save function with Recursive Pre-order
	R_PRE_S(root);
	return true;
}
void AlphabetBST::R_PRE_S(AlphabetNode* currentNode){
	if(currentNode!=NULL){
		currentNode->GetBST()->Save();
		R_PRE_S(currentNode->GetLeft());
		R_PRE_S(currentNode->GetRight());
	}
}

void AlphabetBST::R_PRE(AlphabetNode* currentNode, char *order){ 
	if(currentNode){
		currentNode->GetBST()->Print(order); //Visit
		R_PRE(currentNode->GetLeft(),order); //Go Left
		R_PRE(currentNode->GetRight(),order); //Go right
	}
}
void AlphabetBST::R_IN(AlphabetNode* currentNode, char *order){
	if(currentNode){
		R_IN(currentNode->GetLeft(),order); //Go left
		currentNode->GetBST()->Print(order); //Visit
		R_IN(currentNode->GetRight(),order); //Go right
	}
}
void AlphabetBST::R_POST(AlphabetNode* currentNode, char *order){
	if(currentNode){
		R_POST(currentNode->GetLeft(),order); //Go left
		R_POST(currentNode->GetRight(),order); //Go left
		currentNode->GetBST()->Print(order); //Visit
	}
}
void AlphabetBST::I_LEVEL(char *order){			//Iterative Level Order
	Stack_q q;
	AlphabetNode *currentNode = root;
	while(currentNode){
		currentNode->GetBST()->Print(order); //Visit
		if(currentNode->GetLeft()) q.q_Push(currentNode->GetLeft()); //Push Left Node to Queue
		if(currentNode->GetRight()) q.q_Push(currentNode->GetRight()); //Push Right Node to queue
		if(q.empty()) return; //if queue is empty, end function
		currentNode = q.q_Pop(); //Pop from the queue
	}
}
void	AlphabetBST::I_IN(char *order){ //In-order without recursive
	Stack_q s;
	AlphabetNode * currentNode = root;
	do{
		while(currentNode){
			s.Push(currentNode);
			currentNode = currentNode->GetLeft();
		}
		currentNode = s.Pop();
		if(currentNode == NULL)
			break;
		currentNode->GetBST()->Print(order);
		currentNode = currentNode ->GetRight();
	}while(s.empty()==true);
}

void	AlphabetBST::I_PRE(char *order){//PRE-order without recursive
	Stack_q s;
	AlphabetNode * currentNode = root;
	do{
		if(currentNode)
			break;
		currentNode->GetBST()->Print(order);
		s.Push(currentNode->GetRight());
		s.Push(currentNode->GetLeft());
	}while(s.empty()==false);
}
void	AlphabetBST::I_POST(char *order){ //POST-order without recursive
	Stack_q s;
	AlphabetNode  * currentNode = root, *Copy = NULL;
	do{
		while(currentNode){
			if(currentNode->GetRight())
				s.Push(currentNode->GetRight());
			s.Push(currentNode);
			currentNode = currentNode->GetLeft();

		}
		currentNode = s.Pop();
		if(currentNode->GetRight()!=NULL && currentNode->GetRight() == Copy){
			s.Pop();			
			s.Push(currentNode);
			currentNode = currentNode->GetRight();

		}
		else{
			std::cout << currentNode->GetAlphabet() << std::endl;
			currentNode->GetBST()->Print(order);
			currentNode = NULL;
		}
 	}while(s.empty()==false);
}


Stack_q::Stack_q(){
	pHead ='\0';
}
Stack_q::~Stack_q(){
	//All function 's end condition is stack empty
}
void Stack_q::Push(AlphabetNode * node){
	if(node=='\0')
		return;
	if(pHead =='\0'){
		this->pHead = node;
	}
	else{
		node->SetNext(pHead);
		this->pHead = node;
	}
}
AlphabetNode* Stack_q::Pop(){
	if(pHead == NULL)
		return NULL;
	AlphabetNode * temp;
	temp = pHead;
	pHead =pHead->GetNext();
	return temp;
}
bool Stack_q::empty(){
	if(pHead == '\0')
		return true;
	return false;
}
AlphabetNode *Stack_q::Top(){
	return pHead;
}
void Stack_q::q_Push(AlphabetNode * node)
{
	AlphabetNode *pPre;
	if(pHead == '\0')
	{
		pHead = node; 
	}
	else
	{
		pPre = pHead;
		while(pPre->GetNext()!= '\0')
			pPre = pPre->GetNext();
		pPre->SetNext(node);	
		node->SetNext('\0');
	}
}				
AlphabetNode * Stack_q::q_Pop()
{
	AlphabetNode *pPop = pHead; 

	if(pHead == '\0')
	{
		return '\0';
	}
	pHead = pPop->GetNext();
	pPop->SetNext('\0');
	return pPop; 
}
