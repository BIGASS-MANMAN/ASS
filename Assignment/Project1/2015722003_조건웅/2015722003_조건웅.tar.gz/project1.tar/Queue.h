#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "WordNode.h"

class Queue
{
private:
	WordNode * pHead;
public:
	Queue();
	~Queue();

	void		Push(WordNode * node);				// LOAD, ADD
	WordNode *	Pop();								// MOVE
	WordNode *	Search(char * word);				// SEARCH, UPDATE
	bool		Print();							// PRINT
	bool		Save();								// SAVE
	WordNode * front(){
		return this->pHead;
	}
	bool empty(){
		if(pHead == '\0')
			return true;
		return false;
	}
};

#endif
