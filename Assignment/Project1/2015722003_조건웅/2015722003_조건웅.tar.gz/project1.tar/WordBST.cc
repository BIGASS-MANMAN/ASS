#include "WordBST.h"
#include <iostream>
WordBST::WordBST()
{
	root = '\0';
}
WordBST::~WordBST() //Destructor
{
	Queue q; //Using Level Order to delete
	WordNode *currentNode = root, *tL, *tR;
	while(currentNode){
		tL == currentNode->GetLeft();
		tR == currentNode->GetRight();
		delete currentNode;
		if(tL) q.Push(currentNode->GetLeft());
		if(tR) q.Push(currentNode->GetRight());
		if(q.empty()) 
			break;
		currentNode = q.Pop();
	}
}

void WordBST::Insert(WordNode * node){
	node->SetNext(NULL);
	if(root == '\0'){
		root = node;
		return;
	}
	WordNode *pPrev = root, *pPrev_Prev = '\0';
	while(pPrev){
		pPrev_Prev = pPrev;
		if(strcmp(node->GetWord(),pPrev->GetWord())<0)
			pPrev = pPrev->GetRight();
		else
			pPrev = pPrev->GetLeft();
	}
	if(strcmp(pPrev_Prev->GetWord(),node->GetWord())>0)
		pPrev_Prev->SetRight(node);
	else
		pPrev_Prev->SetLeft(node);
	return;
}
WordNode* WordBST::Delete(char *word){
	WordNode *Copy = new WordNode;
	WordNode *p = root, *pp = '\0';
	while(p && strcmp(word,p->GetWord())){
		pp = p;
		if(word < p->GetWord())
			p = p->GetLeft();
		else
			p = p->GetRight();
	}
	if(p =='\0')
		return '\0';
	Copy->SetWord(p->GetWord());
	Copy->SetMean(p->GetMean());
	//When target Node is Leaf Node
	if(p->GetRight() == '\0' && p->GetLeft()== '\0' ){
		if(pp == '\0')
			root = NULL;
		else if(pp->GetLeft() == p)
			pp->SetLeft(NULL);
		else
			pp->SetRight(NULL);
		delete p;
		return Copy;
	}
	//When target Node's degree is 1.
	if(p->GetLeft() == NULL){
		if(pp == NULL)
			root = p->GetRight();
		else if(pp->GetLeft() == p)
			pp->SetLeft(p->GetRight());
		else
			pp->SetRight(p->GetRight());
		delete p;
		return Copy;
	}
	if(p->GetRight() == NULL){
		if(pp == NULL)
			root = p->GetLeft();
		else if(pp->GetLeft() == p)
			pp->SetLeft(p->GetLeft());
		else
			pp->SetRight(p->GetLeft());
		delete p;
		return Copy;
	}
	//When taget Node's Degree is 2
	WordNode *prev_prev = p, *prev = p->GetRight();
	WordNode *curr = p->GetRight()->GetLeft();
	while(curr){
		prev_prev = prev;
		prev = curr;
		curr = curr->GetLeft();
	}
	p->SetWord(prev->GetWord());
	p->SetMean(prev->GetMean());
	if(prev_prev == p)
		prev_prev->SetRight(prev->GetRight());
	else
		prev_prev->SetLeft(prev->GetRight());
	delete prev;

	return Copy;
}
WordNode* WordBST::Search(char *word){
	WordNode* pSe = root;
	while(pSe){
		if(strncmp(pSe->GetWord(),word,strlen(word))>0)
			pSe = pSe->GetRight();
		else if(strncmp(pSe->GetWord(),word,strlen(word))<0)
			pSe = pSe->GetLeft();
		else if(!strncmp(pSe->GetWord(),word,strlen(word)))
			return pSe;
	}
	return NULL;
}
bool WordBST::Print(char *order){
	char * List[10] ={"R_PRE", "R_IN", "R_POST", "I_LEVEL", "I_PRE","I_IN", "I_POST" };
	int flag;
	for(flag = 0;strncmp(List[flag],order,strlen(List[flag]));flag++);
	switch(flag){
	case 0: 	R_PRE();	break;
	case 1:		R_IN();		break;
	case 2:		R_POST();	break;
	case 3:		I_LEVEL();	break;
	case 4:		R_PRE();	break;
	case 5:		R_IN();		break;
	case 6:		R_POST();	break;
	default:	break;
	}
	return true;
}
bool WordBST::Save(){
	std::ofstream fout;
	fout.open("memorizing_word.txt",std::ios::app);
	Stack s;
	WordNode * currentNode = root;
	s.Push(root);
	while(s.empty()==false){
		currentNode = s.Pop();
		if(currentNode==NULL){
			fout.close();
			return true;
		}
		fout << currentNode->GetWord() <<"\t" << currentNode->GetMean() << std::endl;
		s.Push(currentNode->GetRight());
		s.Push(currentNode->GetLeft());
	}
	fout.close();
	return true;
}
void WordBST::R_PRE(WordNode* currentNode){
	if(currentNode){
		print_log(currentNode->GetWord(),currentNode->GetMean());
		R_PRE(currentNode->GetLeft());
		R_PRE(currentNode->GetRight());
	}
}
void WordBST::R_IN(WordNode* currentNode){
	if(currentNode){
		R_IN(currentNode->GetLeft());
		print_log(currentNode->GetWord(),currentNode->GetMean());
		R_IN(currentNode->GetRight());
	}
}
void WordBST::R_POST(WordNode* currentNode){
	if(currentNode){
		R_POST(currentNode->GetLeft());
		R_POST(currentNode->GetRight());
		print_log(currentNode->GetWord(),currentNode->GetMean());
	}
}
void WordBST::print_log(char *word, char *mean){
	log.open("log.txt",std::ios::app);
	log << word << " " << mean << std::endl;	
	log.close();
}
void WordBST::I_LEVEL(){			//Iterative Level Order
	Queue q;
	WordNode *currentNode = root;
	while(currentNode){
		print_log(currentNode->GetWord(),currentNode->GetMean());
		if(currentNode->GetLeft()) q.Push(currentNode->GetLeft());
		if(currentNode->GetRight()) q.Push(currentNode->GetRight());
		if(q.empty()) return;
		currentNode = q.Pop();
	}
}
void	WordBST::I_IN(){
	Stack s;
	WordNode * currentNode = root;
	if(currentNode == NULL)
		return;
	do{
		while(currentNode){
			s.Push(currentNode);
			currentNode = currentNode->GetLeft();
		}
		currentNode = s.Pop();
		if(currentNode == NULL)
			break;
		print_log(currentNode->GetWord(),currentNode->GetMean());
		currentNode = currentNode ->GetRight();
	}while(s.empty()==true); 
}

void	WordBST::I_PRE(){
	Stack s;
	WordNode * currentNode = root;
	if(currentNode==NULL)
		return;
	do{
		print_log(currentNode->GetWord(),currentNode->GetMean());
		if(currentNode->GetRight()) s.Push(currentNode->GetRight());
		if(currentNode->GetLeft()) s.Push(currentNode->GetLeft());
	}while(s.empty()==false);
}
void	WordBST::I_POST(){
	Stack s;
	WordNode  * currentNode = root, *Copy = NULL;
	do{
		if(currentNode==NULL)
			break;
		while(currentNode){
			if(currentNode->GetRight()!=NULL)
				s.Push(currentNode->GetRight());
			s.Push(currentNode);
			currentNode = currentNode->GetLeft();
		}
		currentNode = s.Pop();
		if(currentNode->GetRight()!=NULL){
			Copy = s.Pop();
			if(currentNode->GetRight() == Copy){
				s.Push(currentNode);
				currentNode = currentNode->GetRight();
			}
			else
				s.Push(Copy);
		}
		else{
			print_log(currentNode->GetWord(),currentNode->GetMean());
			currentNode = NULL;
		}
 	}while(s.empty()==false);
}

Stack::Stack(){
	root ='\0';
}
Stack::~Stack(){
	//while(Pop());
}
void Stack::Push(WordNode * node){
	if(node==NULL)
		return;
	node->SetNext(NULL);
	if(root =='\0'){
		root = node;
	}
	else{
		node->SetNext(root);
		root = node;
	}
}
WordNode* Stack::Pop(){
	WordNode * temp;
	if(root == NULL)
		return NULL;
	temp = root;
	root = root->GetNext();
	temp->SetNext(NULL);
	return temp;
}
bool Stack::empty(){
	if(root == '\0')
		return true;
	return false;
}
WordNode *Stack::Top(){
	return root;
}
