#include "Manager.h"
#include <iostream>

Manager::Manager() //Constructor 
{
	cll = new CircularLinkedList;
	bst = new AlphabetBST;
	queue = new Queue;
	log.open("log.txt",std::ios::out); log.close();
	log.open("log.txt",std::ios::app);
	input = '\0';
}


Manager::~Manager() //Desturctor
{
	delete cll;
	delete bst;
	delete queue;
}
void Manager::run(const char * command)
{
	int flag;
	bool flag_b = true;
	char *List[10]; //Array for Command
	List[0] = "LOAD"; List[1] = "ADD";
	List[2] = "MOVE";  List[3] = "SAVE";
	List[4] = "TEST"; List[5] = "SEARCH";
	List[6] = "PRINT"; List[7] = "UPDATE";
	List[8] = "EXIT";
	fin.open(command,std::ios::in); //file open
	if(fin == '\0') //Wrong open
		return;
	while(!fin.eof()){ //
		bool flag_b = true;
		input = new char[50];
		int cnt = 0;
		fin.getline(input,50,'\n'); //Get line from text
		for(flag=0;strncmp(input, List[flag], strlen(List[flag]));flag++);
		if(flag == 8) //EXIT
			break;
		switch(flag){ //Call Function
			case 0: flag_b = LOAD();  break;
			case 1: flag_b = ADD (); break;
			case 2: flag_b = MOVE(); break;
			case 3: flag_b = SAVE(); break;
			case 4: flag_b = TEST(); break;
			case 5: flag_b = SEARCH(); break;
			case 6: flag_b = PRINT(); break;
			case 7: flag_b = UPDATE(); break;
			default: break; //ERROR
		}
		if(flag_b == false){ //Error Print Function
			log << "======== ERROR ========" << std::endl;
			log << (flag+1)*100 << std::endl;
			log << "=====================" << std::endl << std::endl;
		}
		delete []input;
	}
	log.close(); //close file
	fin.close();
}
bool Manager::LOAD(){ //LOAD function
	char *temp1, *temp2;
	strtok_r(input," ",&temp1);
	if(strtok_r(temp1," ",&temp2)!='\0') //Get parameter
		return false;
	bool re_0 = false, re_1 =false, re_2 = false;
	if(queue->empty()==true) //Print Words
		re_0 = LOAD_file("to_memorize_word.txt",0);
	if(bst->WordCnt == 0)
		re_1 = LOAD_file("memorizing_word.txt",1);
	if(cll->pHead=='\0')
		re_2 = LOAD_file("memorized_word.txt",2);
	if(!re_0 || !re_1 || !re_2) //if wrong result
		return false;
	PS_Log("LOAD"); //Success Function
	return true;
}
bool Manager::ADD(){
	char *temp1, *temp2;
	strtok_r(input," ",&temp1);
	if(strtok_r(temp1," ",&temp2)!='\0')
		return false; //Get Parameter
	std::ifstream L_fin; //file variable
	L_fin.open("word.txt",std::ios::in);
	char *wordmean; 
	WordNode * temp;
	if(L_fin=='\0')
		return false;
	while(L_fin.eof()==0){ 
		wordmean = new char [100];
		temp = new WordNode;
		L_fin.getline(wordmean,100); //Get word and mean from file
		if(wordmean[0]==0){ //if not input break function
			delete temp;
			break;
		}
		temp->SetWord(strtok_r(wordmean,"\t",&temp1)); //set Word to WordNode
		if(bst->Search(temp->GetWord()[0])->GetBST()->Search(temp->GetWord())!='\0') //if same word exist
			continue;
		if(queue->Search(temp->GetWord())!='\0' || cll->Search(temp->GetWord())!='\0')
			continue;
		temp->SetMean(strtok_r(temp1,"\0",&temp2)); //Set Mean to WordNode
 		queue->Push(temp); //Push to queue (to_memorize)
	}
	L_fin.close();
	PS_Log("ADD");
	return true;
}
bool Manager::MOVE(){ //Move function
	char *data, *temp1, *temp2;
	int cnt=0,sum=0,ten=1;
	strtok_r(input," ",&temp1);
	data = strtok_r(temp1,"\0",&temp2); //Get Parameter
	cnt = strlen(data); 
	for(int i=0;i<cnt-1;i++){ //Char -> Pointer
		sum += (int)(data[i]-48);
		sum *= ten;
		ten *= 10;
	} 
	if(bst->GetWordCNT() + sum > 100) //if Memorizing BST's word over 100 
		return false;
	for(int i=0;i<sum;i++){ //Add to BST
		bst->WordCnt++;
		WordNode * queue_pop; //Pop from Queue
		queue_pop = queue->Pop();
 		if(queue_pop == NULL)
			return false;
		char* word = queue_pop->GetWord(); //
		AlphabetNode * temp = bst->Search(word[0]); //if Same word exist
		if(temp!='\0'){
			temp->GetBST()->Insert(queue_pop); //Add to bst
			bst->WordCnt++; //WordCnt ++
		}
	}
	PS_Log("MOVE");
	return true;
}
bool Manager::SAVE(){	
	char * temp1, *temp2;
	strtok_r(input," ",&temp1);
	if(strtok_r(temp1," ",&temp2)!='\0')
		return false; //Get Parameter
	bool re_bst = bst->Save(); //Call Save function
	bool re_cll = cll->Save();
	bool re_queue = queue->Save();
	if(!re_bst && !re_cll && !re_queue) //if all result if false
		return false;
	PS_Log("SAVE");
	return true;
}
bool Manager::TEST(){
	char *temp1, *temp2;
	char *word, *mean;
	WordNode *MEM;
	strtok_r(input," ",&temp1);
	word = strtok_r(temp1," ",&temp2); //get Parameter
	change(word); //Change big to small
	mean = strtok_r(temp2,"\0",&temp1); //get Parameter
	AlphabetNode *temp = bst->Search(word[0]); //Search Word from bst
	MEM = temp->GetBST()->Search(word);
	if(MEM == NULL)
		return false;
	if( strncmp(mean, MEM->GetMean(), strlen(MEM->GetMean()))!=0 ){ //if same word not exist
		return false;
	}
	log << "======== TEST ========" << std::endl;
	log << "Pass" << std::endl;
	log << "=====================" << std::endl << std::endl;
	MEM = temp->GetBST()->Delete(word); //Delete word from BST
	cll->Insert(MEM); //add word to cll
	return true;
}
bool Manager::SEARCH(){ 
	char *data, *temp1, *temp2;
	strtok_r(input," ",&temp1);
	data = strtok_r(temp1," ",&temp2); //Get Parameter
	change(data);
	WordNode *MEM;
	data[strlen(data)-1] = NULL;
	MEM = cll->Search(data); //search Word from CLL
	if(MEM == NULL){ //if word is not exist at Cll
		MEM = bst->Search(data[0])->GetBST()->Search(data); 
	}
	if(MEM == NULL){ //if word is not exist at BST
		MEM = queue->Search(data);
	}
	if(MEM == NULL){ //if word is not exist at queue
		return false;}
	
	log << " ======== SEARCH ========" << std::endl;
	log << MEM->GetWord() << " " << MEM->GetMean() << std::endl;
	log << "=======================" << std::endl << std::endl;
	return true;
}
bool Manager::PRINT(){
	char *data1, *data2 ,*temp1;
	bool re = false; 
	strtok_r(input," ",&temp1);
	data1 = strtok_r(temp1," ",&data2); //Get parameter
	if(!strncmp(data1,"TO_MEMORIZE",11)){ //Call function
		if(data2[0]!=0)
			return false;
		re = queue->Print();
	}
	if(!strncmp(data1,"MEMORIZED",9)){
		if(data2[0]!=0)
			return false;
		re = cll->Print();
	}
	if(!strcmp(data1,"MEMORIZING") && data2!=NULL){
		if(bst->GetWordCNT() == 0)
			return false;
		log << "======== PRINT ========" << std::endl;
 		re = bst->Print(data2);
		log << "=======================" << std::endl << std::endl;
	}
	return re;
}
bool Manager::UPDATE(){ //Update
	char *word, *mean;
	WordNode *MEM;
	strtok(input," ");
	word = strtok(NULL," ");
	change(word);
	mean = strtok(NULL,"\0"); //Get parameter
	MEM = cll->Search(word); //Search word in cll
	if(MEM == '\0')
		MEM = queue->Search(word); //Search word in queue
	if(MEM == '\0')
		MEM = bst->Search(word[0])->GetBST()->Search(word); //Search word in bst
	if(MEM == '\0')
		return false;
	word = MEM->GetMean(); //if same word find, change mean
	MEM->SetMean(mean); 
	log << " ======== UPDATE ========" <<std::endl; //if success, print message
	log << MEM->GetWord() << " " << word << "->" << MEM->GetMean() << std::endl;
	log << " =======================" << std::endl << std::endl;
	return true;
}
bool Manager::LOAD_file(char *filename,int flag){ //help Load_function
	std::fstream fin_Load;
	fin_Load.open(filename,std::ios_base::in);
 	if(!fin_Load){
		fin_Load.open(filename,std::ios::out);
		fin_Load.close();
		return false;
	}
	char * data ,*temp1,*temp2;
	while(!fin_Load.eof()){ //Load_Function
		WordNode * temp = new WordNode;
		data = new char[20];
		fin_Load.getline(data,20);
		if(data[0] == 0)
			break;
		temp->SetWord(strtok_r(data,"\t",&temp1));
		if(bst->Search(temp->GetWord()[0])->GetBST()->Search(temp->GetWord())!='\0') //if same word exist
			continue;
		if(queue->Search(temp->GetWord())!='\0' || cll->Search(temp->GetWord())!='\0') //if same word exist
			continue;
		temp->SetMean(strtok_r(temp1,"\0",&temp2)); //make new node and insert word and mean.
		switch(flag){
		case 0: //insert
			queue->Push(temp);;break;
		case 1:
			bst->Search(temp->GetWord()[0])->GetBST()->Insert(temp);
			bst->WordCnt++; break;
		case 2:
			cll->Insert(temp); ;break;
		}
 	}
	fin_Load.close();
	return true;
}
void Manager::PS_Log(char * input){ //Success function
	log << "======== " << input << "======== " << std::endl;
	log << "Success" << std::endl;
	log << "=====================" << std::endl << std::endl;
	
}
void Manager::change(char *input){ //Change word, big to small
	int cnt =0;
	while(input[cnt]!='\0'){
		if(input[cnt] < 'a')
			input[cnt]+= 32;
		cnt++;
	}
}
