#ifndef _WORDBST_H_
#define _WORDBST_H_

#include "WordNode.h"
#include "Queue.h"
#include <fstream>

class WordBST
{
public:
	WordNode * root;	// Word BST Root
	std::ofstream log;
	void print_log(char *, char *);
public:
	WordBST();
	~WordBST();

	void		Insert(WordNode * node);			// LOAD, MOVE
	WordNode *	Delete(char		* word);				// TEST
	WordNode *	Search(char * word);				// ADD, TEST, SEARCH, UPDATE
	bool		Print(char  * order);							// PRINT
	bool		Save();								// SAVE

	void			R_PRE(){ R_PRE(root); }	
	void			R_IN(){ R_IN(root); }		
	void			R_POST(){ R_POST(root); }	
	
	void			R_PRE(WordNode * currentNode);	   //Recursive Preorder
	void			R_IN(WordNode * currentNode);		//Recursive Inorder						
	void			R_POST(WordNode * currentNode);		//Recursive Postorder		
	
	void			I_LEVEL();						//Iterative Level Order
	void			I_PRE();						//Iterative Preorder
	void			I_IN();							//Iterative Inorder
	void			I_POST();						//Iterative Postorder

};
class Stack{
private:
	WordNode * root;
public:
	Stack();
	~Stack();
	void Push(WordNode *);
	WordNode* Pop();
	bool empty();
	WordNode* Top();
};

#endif
