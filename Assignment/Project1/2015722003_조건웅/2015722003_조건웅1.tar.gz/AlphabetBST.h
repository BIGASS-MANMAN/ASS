#ifndef _ALPHABETBST_H_
#define _ALPHABETBST_H_

#include "AlphabetNode.h"
#define MAX_WORD 100	// Maximum MEMORIZING Words

class AlphabetBST
{
public:
	
	AlphabetNode * root;
	int WordCnt;
public:	
	AlphabetBST();
	~AlphabetBST();

	void			Insert(AlphabetNode * node);	// run
	bool			Print(char * order);			// PRINT
	AlphabetNode *	Search(char alpabet);			// LOAD, MOVE, TEST, SEARCH, UPDATE
	bool			Save();							// SAVE
	int				GetWordCNT(){
		return this->WordCnt;
	}
	
	void R_PRE_S(AlphabetNode* currentNode);	

	void R_PRE(AlphabetNode * currentNode, char *order);	
	void R_IN(AlphabetNode* currentNode, char *order); 							
	void R_POST(AlphabetNode* currentNode, char *order); 
	
	void I_LEVEL(char *order);						//Iterative Level Order
	void I_PRE(char *order);						//Iterative Preorder
	void I_IN(char *order);							//Iterative Inorder
	void I_POST(char *order);						//Iterative Postorder
};
class Stack_q{
private:
	AlphabetNode * pHead;
public:
	Stack_q();
	~Stack_q();
	void Push(AlphabetNode *);
	AlphabetNode* Pop();
	bool empty();
	AlphabetNode* Top();
	AlphabetNode* q_Pop();
	void q_Push(AlphabetNode* );
};

#endif
