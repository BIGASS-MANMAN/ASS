#include "Manager.h"

int main(void)
{
	Manager manager;//declare manager structure manager
	manager.run("command.txt"); //implement command.txt
	return 0;//return 0
}
