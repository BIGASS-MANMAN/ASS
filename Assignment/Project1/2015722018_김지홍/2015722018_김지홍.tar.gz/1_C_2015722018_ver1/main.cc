#include "Manager.h"
#include <iostream>
#include <fstream>
using namespace std;
int main(void)
 {
	Manager manager; //manager variable
	manager.run("command.txt"); //manager start

	return 0;
}