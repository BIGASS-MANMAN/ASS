#include "Manager.h"
int main()
{
	Manager manager;
	manager.run("command.txt");
	return 0;
}
/*
Modefied 10/6 am 2:50
*/