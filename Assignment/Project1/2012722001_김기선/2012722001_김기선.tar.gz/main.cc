#include"Manager.h"

using namespace std;

int main()
{
	Manager manager;
	manager.run("command.txt");
	return 0;
}
