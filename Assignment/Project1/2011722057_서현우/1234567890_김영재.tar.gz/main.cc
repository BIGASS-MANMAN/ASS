#include "Manager.h"
#include <iostream>
#include <fstream>

using namespace std;

int main(void)
{
	
	Manager manager;//Variable declarations manager
	manager.run("command.txt");//Call function "run" of manager class

	return 0;
}
