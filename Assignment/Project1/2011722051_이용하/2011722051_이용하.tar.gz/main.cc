#include "Manager.h"
#include <iostream>

int main(void)
{
	Manager manager;
	manager.run("command.txt");
	return 0;
}
