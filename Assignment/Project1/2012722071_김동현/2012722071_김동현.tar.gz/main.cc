#include "Manager.h"
#include <iostream>
#include <fstream>

using namespace std;

int main(void)
{

	Manager manager;
	manager.run("command.txt");
	return 0;
}
