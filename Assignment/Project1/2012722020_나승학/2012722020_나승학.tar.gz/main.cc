#include "Manager.h"

int main(void)
{
	Manager manager;				// Defining Manager is manager
	manager.run("command.txt");		// manager running
	return 0;						// end of function
}
