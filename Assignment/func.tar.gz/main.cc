#include <iostream>
#include "func.h"
using namespace std;

int main()
{
	Test test;

	// get 2's complement
	cout << test.get2sComplement(1) << endl;
	cout << test.get2sComplement(4) << endl;

	// average
	cout << test.average(1, 2, 3) << endl;
	cout << test.average(10, 10, 10) << endl;
	cout << test.average(33, 44, 55) << endl;

	// secToHMS
	// omitted
	
	// factorial
	cout << test.factorial(2) << endl;
	cout << test.factorial(5) << endl;

	// findMax
	int arr[10] = {6, 4, 5, 8, 7, 2, 1, 3, 0, 9};
	cout << test.findMax(arr, 10) << endl;
	cout << test.findMax(arr, 5) << endl;

	// changeCase
	cout << test.changeCase('a') << endl;
	cout << test.changeCase('A') << endl;

	// sorting
	test.sorting(arr, 10);
	for (int i = 0; i < 10; i++)
		cout << arr[i] << " ";
	cout << endl;

	// get fibonacci
	cout << test.fibonacci(5) << endl;
	cout << test.fibonacci(6) << endl;
	cout << test.fibonacci(7) << endl;
	cout << test.fibonacci(8) << endl;

	// get n-th order
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << test.getN_order(i, j) << " ";
		}
		cout << endl;
	}

	return 0;
}
