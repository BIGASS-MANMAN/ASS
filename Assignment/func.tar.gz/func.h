#pragma once
#ifndef _FUNC_H_
#define _FUNC_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning (disable:4996)

class Test
{
public:
	int get2sComplement(int n);
	double average(const int n1, const int n2, const int n3);
//	char *secToHMS(int sec);
	long int factorial(int n);
	int findMax(int array[], int size);
	char changeCase(char c);
	void sorting(int array[], int size);
	int fibonacci(int i);
	int getN_order(int a, int b);
};

#endif
