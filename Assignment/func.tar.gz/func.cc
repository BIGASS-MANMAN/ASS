#include "func.h"

int Test::get2sComplement(int n) {
	/* this function returns two's complement value about n */
	int result;
	result = ~n;
	result = result + 1;

	return result;
}

double Test::average(const int n1, const int n2, const int n3) {
	/* this function finds the average of three-values */

	return (n1 + n2 + n3) / 3;
	// EXCEPTION POINT
	// it's operation is all about integer. 
	// therefore, it CAN'T COVER PRECISION.
}

//void secToHMS(int s, char *HMS) {
	/* this function is converter from second to formatted string(HH:MM:SS) */
/*	short int _hour, _min, _sec;
	char hour[3] = { 0 }, min[3] = { 0 }, sec[3] = { 0 };

	_sec = s % 60;
	_min = s / 60;
	_hour = _min / 60;
	_min = _min % 60;

	itoa(_sec, sec, 10);
	itoa(_min, min, 10);
	itoa(_hour, hour, 10);

	//concatenate HH:MM:SS
	strcat(HMS, hour);
	strcat(HMS, ":");
	strcat(HMS, min);
	strcat(HMS, ":");
	strcat(HMS, sec);
*/
	//EXCEPTION POINT
	//1. is 's' negative?
	//2. check if array exists
	//3. check if array init as 0.
//}

long int Test::factorial(int n) {
	/* this function finds the value of n!(n factorial) recursively */
	if (n == 1) return 1;
	return n*factorial(n - 1);

	//EXCEPTION POINT
	//1. is 'n' zero?
	//2. is 'n' negative?
}

int Test::findMax(int array[], int size) {
	/* this functions finds max value of elements */
	int i, max;

	max = array[0];
	for (i = 1; i < size; i++) {
		if (max < array[i]) max = array[i];
	}
	return max;
	//EXCEPTION POINT
	//1. is 'size' positive?
	//2. if yes, check if the 'size' exceedss array's size.
}

char Test::changeCase(char c) {
	/* this functions change the alphabet case (upper->lower or lower->upper) */
	if (c >= 'a' && c <= 'z') return c - 32;
	else return c + 32;

	//EXCEPTION POINT
	//1. is 'c' alphabet?
}

void Test::sorting(int array[], int size) {
	/* this function sorts the array */
	int i, j, max, temp;

	for (i = 0; i < size - 1; i++) {
		max = array[i];
		for (j = i + 1; j < size; j++) {
			if (max < array[j]) {
				temp = array[i];
				max = array[i] = array[j];
				array[j] = temp;
			}
		}
	}
	//EXCEPTION POINT
	//1. is 'size' positive?
	//2. if yes, check if the 'size' exceedss array's size.
}

int Test::fibonacci(int num) // only for 4-digit number, i.e. 1000 <= num < 10000
{
	if(num <= 2) return 1;
	return fibonacci(num - 1) + fibonacci(num - 2);
}

int Test::getN_order(int a, int b) // get a*a*a*...*a(b times)
{
	int result = a;

	for(int i = 1; i < b; i++)
		result *= a;

	return result;
}
